"use client"

import { useState, useEffect } from "react"
import { AnimatePresence, motion } from "framer-motion"
import { LoginForm } from "@/components/auth/login-form"
import { Header } from "@/components/layout/header"
import { BottomNav } from "@/components/layout/bottom-nav"
import { DashboardView } from "@/components/dashboard/dashboard-view"
import { RunTracker } from "@/components/run/run-tracker"
import { MapView } from "@/components/map/map-view"
import { LeaderboardView } from "@/components/leaderboard/leaderboard-view"
import { RewardsView } from "@/components/rewards/rewards-view"
import { ProfileView } from "@/components/profile/profile-view"
import { InvestorMode } from "@/components/investor/investor-mode"
import { useAppStore } from "@/lib/store"

export default function Home() {
  const { isAuthenticated, investorMode, toggleInvestorMode } = useAppStore()
  const [activeTab, setActiveTab] = useState("dashboard")
  const [isHydrated, setIsHydrated] = useState(false)

  // Handle hydration
  useEffect(() => {
    setIsHydrated(true)
  }, [])

  if (!isHydrated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
          className="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full"
        />
      </div>
    )
  }

  if (!isAuthenticated) {
    return <LoginForm onSuccess={() => setActiveTab("dashboard")} />
  }

  const renderContent = () => {
    if (investorMode) {
      return <InvestorMode />
    }

    switch (activeTab) {
      case "dashboard":
        return <DashboardView onStartRun={() => setActiveTab("run")} />
      case "run":
        return <RunTracker onComplete={() => setActiveTab("dashboard")} />
      case "map":
        return <MapView />
      case "leaderboard":
        return <LeaderboardView />
      case "rewards":
        return <RewardsView />
      case "profile":
        return <ProfileView onLogout={() => setActiveTab("dashboard")} />
      default:
        return <DashboardView onStartRun={() => setActiveTab("run")} />
    }
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header onInvestorModeToggle={toggleInvestorMode} />

      <main className="flex-1 pt-16 pb-20 overflow-y-auto no-scrollbar">
        <div className="max-w-lg mx-auto min-h-full">
          <AnimatePresence mode="wait">
            <motion.div
              key={investorMode ? "investor" : activeTab}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
              className="min-h-full"
            >
              {renderContent()}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  )
}

"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"

export interface User {
  id: string
  name: string
  email: string
  avatar: string
  level: number
  xp: number
  xpToNextLevel: number
  totalXp: number
  streak: number
  longestStreak: number
  totalRuns: number
  totalDistance: number
  totalCalories: number
  badges: Badge[]
  createdAt: string
}

export interface Badge {
  id: string
  name: string
  description: string
  icon: string
  unlockedAt?: string
  requirement: string
}

export interface Run {
  id: string
  date: string
  duration: number
  distance: number
  pace: number
  calories: number
  xpEarned: number
  route: { lat: number; lng: number }[]
}

export interface Challenge {
  id: string
  title: string
  description: string
  target: number
  progress: number
  unit: string
  xpReward: number
  deadline: string
  completed: boolean
}

export interface LeaderboardEntry {
  id: string
  name: string
  avatar: string
  distance: number
  runs: number
  level: number
  isCurrentUser?: boolean
}

interface AppState {
  user: User | null
  isAuthenticated: boolean
  runs: Run[]
  challenges: Challenge[]
  leaderboard: LeaderboardEntry[]
  activeRun: {
    isRunning: boolean
    isPaused: boolean
    startTime: number | null
    elapsedTime: number
    distance: number
    pace: number
    calories: number
    route: { lat: number; lng: number }[]
  }
  investorMode: boolean

  // Auth actions
  login: (email: string, password: string) => boolean
  signup: (name: string, email: string, password: string) => boolean
  logout: () => void

  // Run actions
  startRun: () => void
  pauseRun: () => void
  resumeRun: () => void
  stopRun: () => Run | null
  updateRunStats: (distance: number, pace: number, calories: number, route: { lat: number; lng: number }[]) => void

  // Gamification actions
  addXp: (amount: number) => void
  incrementStreak: () => void
  updateChallengeProgress: (challengeId: string, progress: number) => void

  // Investor mode
  toggleInvestorMode: () => void
  simulateGrowth: () => void
}

const DEFAULT_BADGES: Badge[] = [
  { id: "1", name: "First Steps", description: "Complete your first run", icon: "🏃", requirement: "1 run" },
  { id: "2", name: "Streak Starter", description: "Maintain a 3-day streak", icon: "🔥", requirement: "3 day streak" },
  { id: "3", name: "Week Warrior", description: "Maintain a 7-day streak", icon: "⚡", requirement: "7 day streak" },
  { id: "4", name: "5K Champion", description: "Run 5km in a single run", icon: "🏅", requirement: "5km single run" },
  { id: "5", name: "10K Master", description: "Run 10km in a single run", icon: "🏆", requirement: "10km single run" },
  { id: "6", name: "Marathon Ready", description: "Run a total of 42.2km", icon: "🎖️", requirement: "42.2km total" },
  { id: "7", name: "Century Club", description: "Run a total of 100km", icon: "💎", requirement: "100km total" },
  { id: "8", name: "Level 10", description: "Reach level 10", icon: "⭐", requirement: "Level 10" },
]

const DEFAULT_CHALLENGES: Challenge[] = [
  {
    id: "1",
    title: "Daily Run",
    description: "Complete any run today",
    target: 1,
    progress: 0,
    unit: "runs",
    xpReward: 50,
    deadline: new Date().toISOString(),
    completed: false,
  },
  {
    id: "2",
    title: "Weekly 20K",
    description: "Run 20km this week",
    target: 20,
    progress: 0,
    unit: "km",
    xpReward: 200,
    deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
    completed: false,
  },
  {
    id: "3",
    title: "5-Day Streak",
    description: "Run 5 days in a row",
    target: 5,
    progress: 0,
    unit: "days",
    xpReward: 300,
    deadline: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
    completed: false,
  },
  {
    id: "4",
    title: "Speed Demon",
    description: "Complete a run under 6:00/km pace",
    target: 1,
    progress: 0,
    unit: "runs",
    xpReward: 150,
    deadline: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(),
    completed: false,
  },
]

const DEFAULT_LEADERBOARD: LeaderboardEntry[] = [
  { id: "1", name: "Alex Runner", avatar: "/athletic-male-avatar.jpg", distance: 87.5, runs: 24, level: 15 },
  { id: "2", name: "Sarah Sprint", avatar: "/athletic-female-avatar.jpg", distance: 76.2, runs: 21, level: 13 },
  { id: "3", name: "Mike Marathon", avatar: "/runner-male-avatar.jpg", distance: 68.9, runs: 18, level: 12 },
  { id: "4", name: "Emma Endurance", avatar: "/fitness-female-avatar.jpg", distance: 54.3, runs: 15, level: 10 },
  { id: "5", name: "James Jogger", avatar: "/jogger-male-avatar.jpg", distance: 45.8, runs: 14, level: 9 },
  { id: "6", name: "Lisa Laps", avatar: "/sporty-female-avatar.jpg", distance: 38.2, runs: 12, level: 8 },
  { id: "7", name: "Chris Cardio", avatar: "/fitness-male-avatar.jpg", distance: 32.1, runs: 10, level: 7 },
  { id: "8", name: "Nina Nimble", avatar: "/athletic-woman-avatar.jpg", distance: 28.7, runs: 9, level: 6 },
]

function calculateXpToNextLevel(level: number): number {
  return Math.floor(100 * Math.pow(1.5, level - 1))
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      runs: [],
      challenges: DEFAULT_CHALLENGES,
      leaderboard: DEFAULT_LEADERBOARD,
      activeRun: {
        isRunning: false,
        isPaused: false,
        startTime: null,
        elapsedTime: 0,
        distance: 0,
        pace: 0,
        calories: 0,
        route: [],
      },
      investorMode: false,

      login: (email: string, password: string) => {
        // Mock authentication
        if (email && password.length >= 4) {
          const existingUser = get().user
          if (existingUser && existingUser.email === email) {
            set({ isAuthenticated: true })
            return true
          }
          // Create new user on login if none exists
          const newUser: User = {
            id: crypto.randomUUID(),
            name: email.split("@")[0],
            email,
            avatar: "/fitness-avatar.png",
            level: 1,
            xp: 0,
            xpToNextLevel: 100,
            totalXp: 0,
            streak: 0,
            longestStreak: 0,
            totalRuns: 0,
            totalDistance: 0,
            totalCalories: 0,
            badges: [],
            createdAt: new Date().toISOString(),
          }
          set({ user: newUser, isAuthenticated: true })
          return true
        }
        return false
      },

      signup: (name: string, email: string, password: string) => {
        if (name && email && password.length >= 4) {
          const newUser: User = {
            id: crypto.randomUUID(),
            name,
            email,
            avatar: "/fitness-avatar.png",
            level: 1,
            xp: 0,
            xpToNextLevel: 100,
            totalXp: 0,
            streak: 0,
            longestStreak: 0,
            totalRuns: 0,
            totalDistance: 0,
            totalCalories: 0,
            badges: [],
            createdAt: new Date().toISOString(),
          }
          set({ user: newUser, isAuthenticated: true })
          return true
        }
        return false
      },

      logout: () => {
        set({ isAuthenticated: false })
      },

      startRun: () => {
        set({
          activeRun: {
            isRunning: true,
            isPaused: false,
            startTime: Date.now(),
            elapsedTime: 0,
            distance: 0,
            pace: 0,
            calories: 0,
            route: [],
          },
        })
      },

      pauseRun: () => {
        set((state) => ({
          activeRun: {
            ...state.activeRun,
            isPaused: true,
          },
        }))
      },

      resumeRun: () => {
        set((state) => ({
          activeRun: {
            ...state.activeRun,
            isPaused: false,
          },
        }))
      },

      updateRunStats: (distance, pace, calories, route) => {
        set((state) => ({
          activeRun: {
            ...state.activeRun,
            distance,
            pace,
            calories,
            route,
          },
        }))
      },

      stopRun: () => {
        const state = get()
        const { activeRun, user } = state

        if (!activeRun.isRunning || !user) return null

        const xpEarned = Math.floor(activeRun.distance * 10) + Math.floor(activeRun.elapsedTime / 60)

        const newRun: Run = {
          id: crypto.randomUUID(),
          date: new Date().toISOString(),
          duration: activeRun.elapsedTime,
          distance: activeRun.distance,
          pace: activeRun.pace,
          calories: activeRun.calories,
          xpEarned,
          route: activeRun.route,
        }

        set((state) => ({
          runs: [newRun, ...state.runs],
          user: state.user
            ? {
                ...state.user,
                totalRuns: state.user.totalRuns + 1,
                totalDistance: state.user.totalDistance + activeRun.distance,
                totalCalories: state.user.totalCalories + activeRun.calories,
              }
            : null,
          activeRun: {
            isRunning: false,
            isPaused: false,
            startTime: null,
            elapsedTime: 0,
            distance: 0,
            pace: 0,
            calories: 0,
            route: [],
          },
        }))

        // Add XP after run
        get().addXp(xpEarned)
        get().incrementStreak()

        return newRun
      },

      addXp: (amount: number) => {
        set((state) => {
          if (!state.user) return state

          let newXp = state.user.xp + amount
          let newLevel = state.user.level
          let xpToNext = state.user.xpToNextLevel

          while (newXp >= xpToNext) {
            newXp -= xpToNext
            newLevel++
            xpToNext = calculateXpToNextLevel(newLevel)
          }

          return {
            user: {
              ...state.user,
              xp: newXp,
              level: newLevel,
              xpToNextLevel: xpToNext,
              totalXp: state.user.totalXp + amount,
            },
          }
        })
      },

      incrementStreak: () => {
        set((state) => {
          if (!state.user) return state
          const newStreak = state.user.streak + 1
          return {
            user: {
              ...state.user,
              streak: newStreak,
              longestStreak: Math.max(newStreak, state.user.longestStreak),
            },
          }
        })
      },

      updateChallengeProgress: (challengeId: string, progress: number) => {
        set((state) => ({
          challenges: state.challenges.map((c) =>
            c.id === challengeId
              ? { ...c, progress: Math.min(progress, c.target), completed: progress >= c.target }
              : c,
          ),
        }))
      },

      toggleInvestorMode: () => {
        set((state) => ({ investorMode: !state.investorMode }))
      },

      simulateGrowth: () => {
        set((state) => {
          if (!state.user) return state
          return {
            user: {
              ...state.user,
              xp: state.user.xp + 500,
              streak: state.user.streak + 1,
              totalRuns: state.user.totalRuns + 3,
              totalDistance: state.user.totalDistance + 15,
            },
          }
        })
      },
    }),
    {
      name: "runify-storage",
    },
  ),
)

export { DEFAULT_BADGES }

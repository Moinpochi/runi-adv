"use client"

import { useState, useEffect, useCallback } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Play, Pause, Square, MapPin, Timer, Flame, Zap } from "lucide-react"
import { useAppStore } from "@/lib/store"
import { Button } from "@/components/ui/button"

interface RunTrackerProps {
  onComplete: () => void
}

// Fake GPS coordinates for simulation (a running route)
const FAKE_ROUTE = [
  { lat: 40.7128, lng: -74.006 },
  { lat: 40.7135, lng: -74.0055 },
  { lat: 40.7142, lng: -74.005 },
  { lat: 40.7148, lng: -74.0045 },
  { lat: 40.7155, lng: -74.004 },
  { lat: 40.716, lng: -74.0035 },
  { lat: 40.7165, lng: -74.003 },
  { lat: 40.717, lng: -74.0025 },
]

export function RunTracker({ onComplete }: RunTrackerProps) {
  const { activeRun, startRun, pauseRun, resumeRun, stopRun, updateRunStats } = useAppStore()
  const [elapsedTime, setElapsedTime] = useState(0)
  const [showCompletionModal, setShowCompletionModal] = useState(false)
  const [completedRun, setCompletedRun] = useState<ReturnType<typeof stopRun>>(null)

  // Simulate distance increase
  const simulateRun = useCallback(() => {
    if (activeRun.isRunning && !activeRun.isPaused) {
      const timeInMinutes = elapsedTime / 60
      const pace = 5.5 + Math.random() * 1 // 5.5-6.5 min/km
      const distance = timeInMinutes / pace // km
      const calories = Math.floor(distance * 60) // ~60 cal per km

      // Get route progress
      const routeIndex = Math.min(Math.floor((distance / 2) * FAKE_ROUTE.length), FAKE_ROUTE.length - 1)
      const route = FAKE_ROUTE.slice(0, routeIndex + 1)

      updateRunStats(Number(distance.toFixed(2)), pace, calories, route)
    }
  }, [activeRun.isRunning, activeRun.isPaused, elapsedTime, updateRunStats])

  // Timer effect
  useEffect(() => {
    let interval: NodeJS.Timeout

    if (activeRun.isRunning && !activeRun.isPaused) {
      interval = setInterval(() => {
        setElapsedTime((prev) => prev + 1)
      }, 1000)
    }

    return () => clearInterval(interval)
  }, [activeRun.isRunning, activeRun.isPaused])

  // Simulate run progress
  useEffect(() => {
    simulateRun()
  }, [elapsedTime, simulateRun])

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600)
    const mins = Math.floor((seconds % 3600) / 60)
    const secs = seconds % 60

    if (hrs > 0) {
      return `${hrs}:${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
    }
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const handleStart = () => {
    setElapsedTime(0)
    startRun()
  }

  const handleStop = () => {
    const run = stopRun()
    if (run) {
      setCompletedRun(run)
      setShowCompletionModal(true)
    }
    setElapsedTime(0)
  }

  const handleDismissCompletion = () => {
    setShowCompletionModal(false)
    setCompletedRun(null)
    onComplete()
  }

  return (
    <div className="px-4 py-6 flex flex-col h-full">
      {/* Run Stats Display */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex-1 flex flex-col items-center justify-center"
      >
        {/* Timer */}
        <div className="text-center mb-8">
          <motion.p className="text-6xl font-mono font-bold text-foreground tracking-tight" key={elapsedTime}>
            {formatTime(elapsedTime)}
          </motion.p>
          <p className="text-muted-foreground mt-2">Duration</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-4 w-full max-w-sm mb-12">
          <div className="glass rounded-2xl p-4 text-center border border-primary/20">
            <MapPin className="w-5 h-5 text-primary mx-auto mb-2" />
            <p className="text-2xl font-bold text-foreground">{activeRun.distance.toFixed(2)}</p>
            <p className="text-xs text-muted-foreground">km</p>
          </div>
          <div className="glass rounded-2xl p-4 text-center border border-accent/20">
            <Timer className="w-5 h-5 text-accent mx-auto mb-2" />
            <p className="text-2xl font-bold text-foreground">{activeRun.pace.toFixed(1)}</p>
            <p className="text-xs text-muted-foreground">min/km</p>
          </div>
          <div className="glass rounded-2xl p-4 text-center border border-orange-400/20">
            <Flame className="w-5 h-5 text-orange-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-foreground">{activeRun.calories}</p>
            <p className="text-xs text-muted-foreground">kcal</p>
          </div>
        </div>

        {/* Control Buttons */}
        <div className="flex items-center gap-4">
          {!activeRun.isRunning ? (
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                onClick={handleStart}
                size="lg"
                className="w-20 h-20 rounded-full bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg neon-glow"
              >
                <Play className="w-8 h-8 ml-1" />
              </Button>
            </motion.div>
          ) : (
            <>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  onClick={handleStop}
                  size="lg"
                  className="w-16 h-16 rounded-full bg-destructive hover:bg-destructive/90 text-destructive-foreground"
                >
                  <Square className="w-6 h-6" />
                </Button>
              </motion.div>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  onClick={activeRun.isPaused ? resumeRun : pauseRun}
                  size="lg"
                  className="w-20 h-20 rounded-full bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg neon-glow"
                >
                  {activeRun.isPaused ? <Play className="w-8 h-8 ml-1" /> : <Pause className="w-8 h-8" />}
                </Button>
              </motion.div>
            </>
          )}
        </div>

        {/* Status text */}
        <p className="text-muted-foreground mt-6">
          {!activeRun.isRunning ? "Tap to start your run" : activeRun.isPaused ? "Run paused" : "Running..."}
        </p>
      </motion.div>

      {/* Completion Modal */}
      <AnimatePresence>
        {showCompletionModal && completedRun && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="glass rounded-3xl p-6 w-full max-w-sm border border-primary/30 neon-glow"
            >
              <div className="text-center mb-6">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", delay: 0.2 }}
                  className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4"
                >
                  <Zap className="w-8 h-8 text-primary" />
                </motion.div>
                <h2 className="text-2xl font-bold text-foreground">Run Complete!</h2>
                <p className="text-muted-foreground mt-1">Great job on your run</p>
              </div>

              <div className="space-y-3 mb-6">
                <div className="flex justify-between py-2 border-b border-border/50">
                  <span className="text-muted-foreground">Distance</span>
                  <span className="font-semibold text-foreground">{completedRun.distance.toFixed(2)} km</span>
                </div>
                <div className="flex justify-between py-2 border-b border-border/50">
                  <span className="text-muted-foreground">Duration</span>
                  <span className="font-semibold text-foreground">{formatTime(completedRun.duration)}</span>
                </div>
                <div className="flex justify-between py-2 border-b border-border/50">
                  <span className="text-muted-foreground">Pace</span>
                  <span className="font-semibold text-foreground">{completedRun.pace.toFixed(1)} min/km</span>
                </div>
                <div className="flex justify-between py-2 border-b border-border/50">
                  <span className="text-muted-foreground">Calories</span>
                  <span className="font-semibold text-foreground">{completedRun.calories} kcal</span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-primary font-medium">XP Earned</span>
                  <span className="font-bold text-primary">+{completedRun.xpEarned} XP</span>
                </div>
              </div>

              <Button
                onClick={handleDismissCompletion}
                className="w-full h-12 rounded-xl bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
              >
                Continue
              </Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

"use client"

import { motion } from "framer-motion"
import { Gift, Lock, Star, Crown, Sparkles } from "lucide-react"
import { useAppStore } from "@/lib/store"
import { Button } from "@/components/ui/button"

const REWARDS = [
  {
    id: "1",
    name: "Custom Avatar Frame",
    description: "Unlock a unique avatar border",
    pointsCost: 500,
    icon: Star,
    category: "cosmetic",
  },
  {
    id: "2",
    name: "Premium Badge",
    description: "Show off your dedication",
    pointsCost: 1000,
    icon: Crown,
    category: "cosmetic",
  },
  {
    id: "3",
    name: "XP Boost (2x)",
    description: "Double XP for your next 3 runs",
    pointsCost: 750,
    icon: Sparkles,
    category: "boost",
  },
  {
    id: "4",
    name: "Exclusive Theme",
    description: "Unlock the Midnight Runner theme",
    pointsCost: 1500,
    icon: Gift,
    category: "cosmetic",
  },
  {
    id: "5",
    name: "Challenge Skip",
    description: "Complete any challenge instantly",
    pointsCost: 2000,
    icon: Star,
    category: "utility",
  },
]

export function RewardsView() {
  const { user } = useAppStore()
  const points = user?.totalXp || 0

  return (
    <div className="px-4 py-6 space-y-6">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-bold text-foreground">Rewards</h1>
        <p className="text-muted-foreground mt-1">Redeem your hard-earned XP</p>
      </motion.div>

      {/* Points Balance */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass rounded-2xl p-6 border border-primary/30 neon-glow text-center"
      >
        <p className="text-muted-foreground mb-2">Available Points</p>
        <p className="text-4xl font-bold text-primary">{points.toLocaleString()}</p>
        <p className="text-sm text-muted-foreground mt-1">XP Points</p>
      </motion.div>

      {/* Premium Banner */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass rounded-2xl p-5 border border-accent/30 bg-gradient-to-r from-accent/10 to-primary/10"
      >
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-accent/20 flex items-center justify-center">
            <Crown className="w-6 h-6 text-accent" />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-foreground">Runify Premium</h3>
            <p className="text-sm text-muted-foreground">Unlock all rewards + exclusive features</p>
          </div>
          <Button size="sm" className="bg-accent hover:bg-accent/90 text-accent-foreground">
            Upgrade
          </Button>
        </div>
      </motion.div>

      {/* Rewards Grid */}
      <div>
        <h2 className="text-lg font-semibold text-foreground mb-3">Available Rewards</h2>
        <div className="space-y-3">
          {REWARDS.map((reward, index) => {
            const canAfford = points >= reward.pointsCost
            const Icon = reward.icon

            return (
              <motion.div
                key={reward.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`glass rounded-2xl p-4 border ${canAfford ? "border-primary/20" : "border-border/30"}`}
              >
                <div className="flex items-center gap-4">
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      canAfford ? "bg-primary/20" : "bg-secondary"
                    }`}
                  >
                    {canAfford ? (
                      <Icon className="w-6 h-6 text-primary" />
                    ) : (
                      <Lock className="w-5 h-5 text-muted-foreground" />
                    )}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium text-foreground">{reward.name}</h3>
                    <p className="text-sm text-muted-foreground">{reward.description}</p>
                  </div>
                  <div className="text-right">
                    <p className={`font-semibold ${canAfford ? "text-primary" : "text-muted-foreground"}`}>
                      {reward.pointsCost.toLocaleString()}
                    </p>
                    <p className="text-xs text-muted-foreground">XP</p>
                  </div>
                </div>
                {canAfford && (
                  <Button
                    size="sm"
                    className="w-full mt-3 bg-primary/10 hover:bg-primary/20 text-primary border border-primary/20"
                  >
                    Redeem
                  </Button>
                )}
              </motion.div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

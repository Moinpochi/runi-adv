"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { TrendingUp, Users, DollarSign, Activity, Play, BarChart3, Target, Zap, ArrowUpRight } from "lucide-react"
import { useAppStore } from "@/lib/store"
import { Button } from "@/components/ui/button"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts"

const GROWTH_DATA = [
  { month: "Jan", dau: 1200, revenue: 2400 },
  { month: "Feb", dau: 2800, revenue: 5600 },
  { month: "Mar", dau: 5200, revenue: 12400 },
  { month: "Apr", dau: 9800, revenue: 28800 },
  { month: "May", dau: 18500, revenue: 62000 },
  { month: "Jun", dau: 35000, revenue: 145000 },
]

const METRICS = [
  { label: "Daily Active Users", value: "35,240", change: "+89%", icon: Users },
  { label: "Monthly Revenue", value: "$145K", change: "+134%", icon: DollarSign },
  { label: "Retention (D7)", value: "68%", change: "+12%", icon: Activity },
  { label: "Avg. Session", value: "12.4m", change: "+24%", icon: Target },
]

export function InvestorMode() {
  const { simulateGrowth, user } = useAppStore()
  const [isSimulating, setIsSimulating] = useState(false)
  const [simulationCount, setSimulationCount] = useState(0)

  const handleSimulate = () => {
    setIsSimulating(true)
    setSimulationCount((c) => c + 1)
    simulateGrowth()
    setTimeout(() => setIsSimulating(false), 500)
  }

  return (
    <div className="px-4 py-6 space-y-6 pb-24">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center gap-2 mb-2">
          <div className="px-2 py-1 rounded-full bg-accent/20 text-accent text-xs font-medium">Demo Mode</div>
        </div>
        <h1 className="text-2xl font-bold text-foreground">Investor Dashboard</h1>
        <p className="text-muted-foreground mt-1">Live metrics and growth simulation</p>
      </motion.div>

      {/* Simulate Button */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <Button
          onClick={handleSimulate}
          disabled={isSimulating}
          className="w-full h-14 rounded-2xl bg-accent hover:bg-accent/90 text-accent-foreground font-semibold text-lg gap-3"
        >
          {isSimulating ? (
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 0.5, repeat: Number.POSITIVE_INFINITY }}
              className="w-5 h-5 border-2 border-accent-foreground/30 border-t-accent-foreground rounded-full"
            />
          ) : (
            <>
              <Play className="w-5 h-5" />
              Simulate Growth ({simulationCount})
            </>
          )}
        </Button>
      </motion.div>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 gap-3">
        {METRICS.map((metric, index) => (
          <motion.div
            key={metric.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="glass rounded-2xl p-4 border border-border/30"
          >
            <metric.icon className="w-5 h-5 text-primary mb-2" />
            <p className="text-xl font-bold text-foreground">{metric.value}</p>
            <div className="flex items-center justify-between mt-1">
              <p className="text-xs text-muted-foreground">{metric.label}</p>
              <span className="text-xs text-primary flex items-center gap-0.5">
                <ArrowUpRight className="w-3 h-3" />
                {metric.change}
              </span>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Growth Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass rounded-2xl p-5 border border-border/30"
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-primary" />
            <h3 className="font-semibold text-foreground">User Growth</h3>
          </div>
          <span className="text-sm text-muted-foreground">Last 6 months</span>
        </div>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={GROWTH_DATA}>
              <defs>
                <linearGradient id="colorDau" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.8 0.2 145)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="oklch(0.8 0.2 145)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.02 240)" />
              <XAxis dataKey="month" stroke="oklch(0.65 0 0)" fontSize={12} />
              <YAxis stroke="oklch(0.65 0 0)" fontSize={12} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "oklch(0.13 0.01 240)",
                  border: "1px solid oklch(0.25 0.02 240)",
                  borderRadius: "12px",
                }}
                labelStyle={{ color: "oklch(0.95 0 0)" }}
              />
              <Area
                type="monotone"
                dataKey="dau"
                stroke="oklch(0.8 0.2 145)"
                fillOpacity={1}
                fill="url(#colorDau)"
                strokeWidth={2}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      {/* Revenue Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass rounded-2xl p-5 border border-border/30"
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-accent" />
            <h3 className="font-semibold text-foreground">Revenue Growth</h3>
          </div>
          <span className="text-sm text-muted-foreground">MRR</span>
        </div>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={GROWTH_DATA}>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.02 240)" />
              <XAxis dataKey="month" stroke="oklch(0.65 0 0)" fontSize={12} />
              <YAxis stroke="oklch(0.65 0 0)" fontSize={12} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "oklch(0.13 0.01 240)",
                  border: "1px solid oklch(0.25 0.02 240)",
                  borderRadius: "12px",
                }}
                formatter={(value: number) => [`$${value.toLocaleString()}`, "Revenue"]}
                labelStyle={{ color: "oklch(0.95 0 0)" }}
              />
              <Line
                type="monotone"
                dataKey="revenue"
                stroke="oklch(0.75 0.15 195)"
                strokeWidth={2}
                dot={{ fill: "oklch(0.75 0.15 195)" }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      {/* Business Model */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass rounded-2xl p-5 border border-border/30"
      >
        <div className="flex items-center gap-2 mb-4">
          <DollarSign className="w-5 h-5 text-primary" />
          <h3 className="font-semibold text-foreground">Business Model</h3>
        </div>
        <div className="space-y-3">
          <div className="flex justify-between py-2 border-b border-border/30">
            <span className="text-muted-foreground">Freemium Users</span>
            <span className="font-medium text-foreground">85%</span>
          </div>
          <div className="flex justify-between py-2 border-b border-border/30">
            <span className="text-muted-foreground">Premium ($9.99/mo)</span>
            <span className="font-medium text-primary">12%</span>
          </div>
          <div className="flex justify-between py-2 border-b border-border/30">
            <span className="text-muted-foreground">Enterprise</span>
            <span className="font-medium text-accent">3%</span>
          </div>
          <div className="flex justify-between py-2">
            <span className="text-muted-foreground">LTV:CAC Ratio</span>
            <span className="font-bold text-primary">4.2x</span>
          </div>
        </div>
      </motion.div>

      {/* Current User Stats (from simulation) */}
      {user && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass rounded-2xl p-5 border border-primary/20"
        >
          <div className="flex items-center gap-2 mb-4">
            <Zap className="w-5 h-5 text-primary" />
            <h3 className="font-semibold text-foreground">Simulated User Progress</h3>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-2xl font-bold text-foreground">{user.totalXp.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">Total XP</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{user.streak}</p>
              <p className="text-xs text-muted-foreground">Day Streak</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{user.totalRuns}</p>
              <p className="text-xs text-muted-foreground">Total Runs</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{user.totalDistance.toFixed(1)} km</p>
              <p className="text-xs text-muted-foreground">Distance</p>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  )
}

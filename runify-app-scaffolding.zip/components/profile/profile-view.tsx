"use client"

import { motion } from "framer-motion"
import { Settings, LogOut, Trophy, MapPin, Flame, Zap, ChevronRight } from "lucide-react"
import { useAppStore, DEFAULT_BADGES } from "@/lib/store"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"

interface ProfileViewProps {
  onLogout: () => void
}

export function ProfileView({ onLogout }: ProfileViewProps) {
  const { user, runs, logout } = useAppStore()

  const handleLogout = () => {
    logout()
    onLogout()
  }

  if (!user) return null

  const stats = [
    { icon: MapPin, label: "Total Distance", value: `${user.totalDistance.toFixed(1)} km`, color: "text-primary" },
    { icon: Trophy, label: "Total Runs", value: user.totalRuns.toString(), color: "text-accent" },
    { icon: Flame, label: "Best Streak", value: `${user.longestStreak} days`, color: "text-orange-400" },
    { icon: Zap, label: "Total XP", value: user.totalXp.toLocaleString(), color: "text-yellow-400" },
  ]

  return (
    <div className="px-4 py-6 space-y-6">
      {/* Profile Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-4">
        <Avatar className="w-20 h-20 border-2 border-primary/30">
          <AvatarImage src={user.avatar || "/placeholder.svg"} />
          <AvatarFallback className="text-2xl">{user.name[0]}</AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <h1 className="text-2xl font-bold text-foreground">{user.name}</h1>
          <p className="text-muted-foreground">{user.email}</p>
          <div className="flex items-center gap-2 mt-2">
            <span className="px-2 py-0.5 rounded-full bg-primary/10 text-primary text-xs font-medium">
              Level {user.level}
            </span>
            <span className="px-2 py-0.5 rounded-full bg-accent/10 text-accent text-xs font-medium">
              {user.streak} day streak
            </span>
          </div>
        </div>
      </motion.div>

      {/* XP Progress */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass rounded-2xl p-4 border border-primary/20"
      >
        <div className="flex justify-between text-sm mb-2">
          <span className="text-muted-foreground">Level {user.level}</span>
          <span className="text-foreground font-medium">
            {user.xp} / {user.xpToNextLevel} XP
          </span>
        </div>
        <div className="relative h-2 bg-secondary rounded-full overflow-hidden">
          <motion.div
            className="absolute inset-y-0 left-0 bg-primary rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${(user.xp / user.xpToNextLevel) * 100}%` }}
          />
        </div>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-3">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="glass rounded-2xl p-4 border border-border/30"
          >
            <stat.icon className={`w-5 h-5 ${stat.color} mb-2`} />
            <p className="text-xl font-bold text-foreground">{stat.value}</p>
            <p className="text-xs text-muted-foreground">{stat.label}</p>
          </motion.div>
        ))}
      </div>

      {/* Badges */}
      <div>
        <h2 className="text-lg font-semibold text-foreground mb-3">Badges</h2>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass rounded-2xl p-4 border border-border/30"
        >
          <div className="grid grid-cols-4 gap-3">
            {DEFAULT_BADGES.slice(0, 8).map((badge, index) => {
              const isUnlocked = user.badges.some((b) => b.id === badge.id)
              return (
                <motion.div
                  key={badge.id}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.05 }}
                  className={`aspect-square rounded-xl flex items-center justify-center text-2xl ${
                    isUnlocked ? "bg-primary/20" : "bg-secondary/50 opacity-40"
                  }`}
                  title={badge.name}
                >
                  {badge.icon}
                </motion.div>
              )
            })}
          </div>
          <p className="text-center text-sm text-muted-foreground mt-3">
            {user.badges.length} / {DEFAULT_BADGES.length} badges unlocked
          </p>
        </motion.div>
      </div>

      {/* Recent Runs */}
      {runs.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-semibold text-foreground">Recent Runs</h2>
            <button className="text-sm text-primary flex items-center gap-1">
              View all <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          <div className="space-y-2">
            {runs.slice(0, 3).map((run, index) => (
              <motion.div
                key={run.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="glass rounded-xl p-3 border border-border/30 flex items-center justify-between"
              >
                <div>
                  <p className="font-medium text-foreground">{run.distance.toFixed(2)} km</p>
                  <p className="text-xs text-muted-foreground">{new Date(run.date).toLocaleDateString()}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-primary font-medium">+{run.xpEarned} XP</p>
                  <p className="text-xs text-muted-foreground">
                    {Math.floor(run.duration / 60)}:{(run.duration % 60).toString().padStart(2, "0")}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="space-y-2 pt-4">
        <Button
          variant="outline"
          className="w-full justify-start gap-3 h-12 rounded-xl border-border/50 bg-transparent"
        >
          <Settings className="w-5 h-5" />
          Settings
        </Button>
        <Button
          variant="outline"
          onClick={handleLogout}
          className="w-full justify-start gap-3 h-12 rounded-xl border-destructive/30 text-destructive hover:bg-destructive/10 bg-transparent"
        >
          <LogOut className="w-5 h-5" />
          Logout
        </Button>
      </div>
    </div>
  )
}

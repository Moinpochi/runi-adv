"use client"

import { motion } from "framer-motion"
import { Bell, Settings, Zap, FlaskConical } from "lucide-react"
import { useAppStore } from "@/lib/store"

interface HeaderProps {
  onInvestorModeToggle?: () => void
}

export function Header({ onInvestorModeToggle }: HeaderProps) {
  const { user, investorMode } = useAppStore()

  return (
    <header className="fixed top-0 left-0 right-0 z-50 safe-area-top">
      <div className="glass-strong border-b border-border/30">
        <div className="flex items-center justify-between px-4 py-3 max-w-lg mx-auto">
          {/* Logo */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-2"
          >
            <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
              <Zap className="w-4 h-4 text-primary" />
            </div>
            <span className="font-bold text-lg text-foreground">Runify</span>
          </motion.div>

          {/* User XP & Actions */}
          <div className="flex items-center gap-3">
            {user && (
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20"
              >
                <Zap className="w-3.5 h-3.5 text-primary" />
                <span className="text-xs font-semibold text-primary">Lv.{user.level}</span>
              </motion.div>
            )}

            <button
              onClick={onInvestorModeToggle}
              className={`p-2 rounded-xl transition-colors ${
                investorMode
                  ? "bg-accent/20 text-accent"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
              }`}
              title="Investor Demo Mode"
            >
              <FlaskConical className="w-5 h-5" />
            </button>

            <button className="p-2 rounded-xl text-muted-foreground hover:text-foreground hover:bg-secondary/50 transition-colors relative">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-primary rounded-full" />
            </button>

            <button className="p-2 rounded-xl text-muted-foreground hover:text-foreground hover:bg-secondary/50 transition-colors">
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  )
}

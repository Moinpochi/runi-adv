"use client"

import { motion } from "framer-motion"
import { Home, MapPin, Trophy, Gift, User, Play } from "lucide-react"
import { cn } from "@/lib/utils"

interface BottomNavProps {
  activeTab: string
  onTabChange: (tab: string) => void
}

const tabs = [
  { id: "dashboard", icon: Home, label: "Home" },
  { id: "run", icon: Play, label: "Run" },
  { id: "map", icon: MapPin, label: "Map" },
  { id: "leaderboard", icon: Trophy, label: "Rank" },
  { id: "rewards", icon: Gift, label: "Rewards" },
  { id: "profile", icon: User, label: "Profile" },
]

export function BottomNav({ activeTab, onTabChange }: BottomNavProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 safe-area-bottom">
      <div className="glass-strong border-t border-border/30">
        <div className="flex items-center justify-around px-2 py-2 max-w-lg mx-auto">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id
            const Icon = tab.icon

            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={cn(
                  "relative flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-all",
                  isActive ? "text-primary" : "text-muted-foreground",
                )}
              >
                {isActive && (
                  <motion.div
                    layoutId="activeTab"
                    className="absolute inset-0 bg-primary/10 rounded-xl"
                    transition={{ type: "spring", stiffness: 500, damping: 30 }}
                  />
                )}
                <Icon className={cn("w-5 h-5 relative z-10", isActive && "drop-shadow-[0_0_8px_var(--primary)]")} />
                <span className="text-[10px] font-medium relative z-10">{tab.label}</span>
              </button>
            )
          })}
        </div>
      </div>
    </nav>
  )
}

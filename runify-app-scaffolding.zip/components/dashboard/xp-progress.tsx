"use client"

import { motion } from "framer-motion"
import { Zap, Star } from "lucide-react"
import { useAppStore } from "@/lib/store"

export function XpProgress() {
  const { user } = useAppStore()

  if (!user) return null

  const progress = (user.xp / user.xpToNextLevel) * 100

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass rounded-2xl p-5 border border-primary/20"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
              <Star className="w-6 h-6 text-primary" />
            </div>
            <motion.div
              className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-primary flex items-center justify-center text-[10px] font-bold text-primary-foreground"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", delay: 0.3 }}
            >
              {user.level}
            </motion.div>
          </div>
          <div>
            <h3 className="font-semibold text-foreground">Level {user.level}</h3>
            <p className="text-sm text-muted-foreground">
              {user.xp} / {user.xpToNextLevel} XP
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-accent/10 border border-accent/20">
          <Zap className="w-4 h-4 text-accent" />
          <span className="text-sm font-medium text-accent">+{Math.round(user.xpToNextLevel - user.xp)} to go</span>
        </div>
      </div>

      {/* Progress bar */}
      <div className="relative h-3 bg-secondary rounded-full overflow-hidden">
        <motion.div
          className="absolute inset-y-0 left-0 bg-gradient-to-r from-primary to-accent rounded-full"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 1, ease: "easeOut" }}
        />
        <motion.div
          className="absolute inset-y-0 left-0 bg-gradient-to-r from-primary/50 to-accent/50 rounded-full blur-sm"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 1, ease: "easeOut" }}
        />
      </div>
    </motion.div>
  )
}

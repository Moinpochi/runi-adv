"use client"

import { motion } from "framer-motion"
import { Flame, MapPin, Zap, Activity } from "lucide-react"
import { useAppStore } from "@/lib/store"

export function StatsCards() {
  const { user } = useAppStore()

  if (!user) return null

  const stats = [
    {
      icon: Flame,
      label: "Streak",
      value: user.streak,
      unit: "days",
      color: "text-orange-400",
      bgColor: "bg-orange-400/10",
      borderColor: "border-orange-400/20",
    },
    {
      icon: MapPin,
      label: "Total Distance",
      value: user.totalDistance.toFixed(1),
      unit: "km",
      color: "text-primary",
      bgColor: "bg-primary/10",
      borderColor: "border-primary/20",
    },
    {
      icon: Zap,
      label: "Total XP",
      value: user.totalXp,
      unit: "xp",
      color: "text-accent",
      bgColor: "bg-accent/10",
      borderColor: "border-accent/20",
    },
    {
      icon: Activity,
      label: "Calories",
      value: user.totalCalories,
      unit: "kcal",
      color: "text-rose-400",
      bgColor: "bg-rose-400/10",
      borderColor: "border-rose-400/20",
    },
  ]

  return (
    <div className="grid grid-cols-2 gap-3">
      {stats.map((stat, index) => (
        <motion.div
          key={stat.label}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className={`glass rounded-2xl p-4 ${stat.borderColor} border`}
        >
          <div className={`inline-flex p-2 rounded-xl ${stat.bgColor} mb-3`}>
            <stat.icon className={`w-5 h-5 ${stat.color}`} />
          </div>
          <div className="space-y-1">
            <p className="text-2xl font-bold text-foreground">
              <AnimatedNumber value={Number(stat.value)} />
            </p>
            <p className="text-xs text-muted-foreground">
              {stat.label} <span className="text-foreground/50">{stat.unit}</span>
            </p>
          </div>
        </motion.div>
      ))}
    </div>
  )
}

function AnimatedNumber({ value }: { value: number }) {
  return (
    <motion.span
      key={value}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      {value.toLocaleString()}
    </motion.span>
  )
}

"use client"

import { motion } from "framer-motion"
import { StatsCards } from "./stats-cards"
import { XpProgress } from "./xp-progress"
import { ActiveChallenge } from "./active-challenge"
import { useAppStore } from "@/lib/store"
import { Play } from "lucide-react"

interface DashboardViewProps {
  onStartRun: () => void
}

export function DashboardView({ onStartRun }: DashboardViewProps) {
  const { user } = useAppStore()

  return (
    <div className="px-4 py-6 space-y-6">
      {/* Welcome */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-bold text-foreground">Welcome back, {user?.name?.split(" ")[0] || "Runner"}!</h1>
        <p className="text-muted-foreground mt-1">Ready for today&apos;s run?</p>
      </motion.div>

      {/* Quick Start Button */}
      <motion.button
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={onStartRun}
        className="w-full glass rounded-2xl p-6 border border-primary/30 neon-glow flex items-center justify-between group"
      >
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-primary flex items-center justify-center shadow-lg">
            <Play className="w-7 h-7 text-primary-foreground ml-1" />
          </div>
          <div className="text-left">
            <h3 className="font-semibold text-lg text-foreground">Start Running</h3>
            <p className="text-sm text-muted-foreground">Track your run and earn XP</p>
          </div>
        </div>
        <motion.div
          className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center"
          animate={{ x: [0, 5, 0] }}
          transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY }}
        >
          <svg className="w-5 h-5 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </motion.div>
      </motion.button>

      {/* XP Progress */}
      <XpProgress />

      {/* Stats Grid */}
      <div>
        <h2 className="text-lg font-semibold text-foreground mb-3">Your Stats</h2>
        <StatsCards />
      </div>

      {/* Active Challenge */}
      <div>
        <h2 className="text-lg font-semibold text-foreground mb-3">Active Challenge</h2>
        <ActiveChallenge />
      </div>
    </div>
  )
}

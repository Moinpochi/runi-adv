"use client"

import { motion } from "framer-motion"
import { Target, Clock, Zap } from "lucide-react"
import { useAppStore } from "@/lib/store"

export function ActiveChallenge() {
  const { challenges } = useAppStore()

  const activeChallenge = challenges.find((c) => !c.completed)

  if (!activeChallenge) return null

  const progress = (activeChallenge.progress / activeChallenge.target) * 100
  const deadline = new Date(activeChallenge.deadline)
  const daysLeft = Math.ceil((deadline.getTime() - Date.now()) / (1000 * 60 * 60 * 24))

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass rounded-2xl p-5 border border-accent/20"
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-accent/20 flex items-center justify-center">
            <Target className="w-5 h-5 text-accent" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">{activeChallenge.title}</h3>
            <p className="text-sm text-muted-foreground">{activeChallenge.description}</p>
          </div>
        </div>
      </div>

      {/* Progress */}
      <div className="space-y-2 mb-4">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Progress</span>
          <span className="text-foreground font-medium">
            {activeChallenge.progress} / {activeChallenge.target} {activeChallenge.unit}
          </span>
        </div>
        <div className="relative h-2 bg-secondary rounded-full overflow-hidden">
          <motion.div
            className="absolute inset-y-0 left-0 bg-accent rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between text-sm">
        <div className="flex items-center gap-1.5 text-muted-foreground">
          <Clock className="w-4 h-4" />
          <span>{daysLeft} days left</span>
        </div>
        <div className="flex items-center gap-1.5 text-primary">
          <Zap className="w-4 h-4" />
          <span className="font-medium">+{activeChallenge.xpReward} XP</span>
        </div>
      </div>
    </motion.div>
  )
}

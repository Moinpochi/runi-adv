"use client"

import { motion } from "framer-motion"
import { MapPin, Layers, Navigation } from "lucide-react"
import { useAppStore } from "@/lib/store"

export function MapView() {
  const { runs, user } = useAppStore()

  const totalTerritory = runs.length * 0.5 // Fake territory calculation

  return (
    <div className="h-full flex flex-col">
      {/* Map Container - Placeholder */}
      <div className="flex-1 relative bg-secondary/20">
        {/* Fake Map Background */}
        <div className="absolute inset-0 opacity-30">
          <svg width="100%" height="100%" className="text-border">
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="0.5" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>

        {/* Map Overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-transparent to-background/80" />

        {/* Fake Territory Zones */}
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 0.3 }}
            transition={{ duration: 1 }}
            className="w-48 h-48 rounded-full bg-primary blur-3xl"
          />
        </div>

        {/* Center Pin */}
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.div
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
            className="flex flex-col items-center"
          >
            <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center shadow-lg neon-glow">
              <Navigation className="w-6 h-6 text-primary-foreground" />
            </div>
            <div className="w-3 h-3 rounded-full bg-primary/50 mt-1" />
          </motion.div>
        </div>

        {/* Map Controls */}
        <div className="absolute top-4 right-4 flex flex-col gap-2">
          <button className="w-10 h-10 rounded-xl glass flex items-center justify-center text-foreground">
            <Layers className="w-5 h-5" />
          </button>
          <button className="w-10 h-10 rounded-xl glass flex items-center justify-center text-foreground">
            <MapPin className="w-5 h-5" />
          </button>
        </div>

        {/* Coming Soon Overlay */}
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass rounded-2xl p-6 text-center max-w-xs mx-4 border border-primary/20"
          >
            <MapPin className="w-10 h-10 text-primary mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-foreground mb-2">Live Map Coming Soon</h3>
            <p className="text-sm text-muted-foreground">
              Real GPS tracking with Mapbox integration and territory capture
            </p>
          </motion.div>
        </div>
      </div>

      {/* Bottom Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-strong border-t border-border/30 p-4"
      >
        <div className="flex items-center justify-around max-w-lg mx-auto">
          <div className="text-center">
            <p className="text-2xl font-bold text-primary">{totalTerritory.toFixed(1)}</p>
            <p className="text-xs text-muted-foreground">km² captured</p>
          </div>
          <div className="w-px h-10 bg-border/50" />
          <div className="text-center">
            <p className="text-2xl font-bold text-foreground">{runs.length}</p>
            <p className="text-xs text-muted-foreground">total runs</p>
          </div>
          <div className="w-px h-10 bg-border/50" />
          <div className="text-center">
            <p className="text-2xl font-bold text-accent">{user?.totalDistance.toFixed(1) || 0}</p>
            <p className="text-xs text-muted-foreground">km total</p>
          </div>
        </div>
      </motion.div>
    </div>
  )
}

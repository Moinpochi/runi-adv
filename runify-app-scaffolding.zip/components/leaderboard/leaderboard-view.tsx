"use client"

import { motion } from "framer-motion"
import { Trophy, Medal, TrendingUp } from "lucide-react"
import { useAppStore } from "@/lib/store"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export function LeaderboardView() {
  const { leaderboard, user } = useAppStore()

  // Add current user to leaderboard and sort
  const fullLeaderboard = [...leaderboard]
  if (user) {
    const userEntry = {
      id: user.id,
      name: user.name,
      avatar: user.avatar,
      distance: user.totalDistance,
      runs: user.totalRuns,
      level: user.level,
      isCurrentUser: true,
    }
    fullLeaderboard.push(userEntry)
  }

  const sortedLeaderboard = fullLeaderboard.sort((a, b) => b.distance - a.distance).slice(0, 10)

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="w-5 h-5 text-yellow-400" />
      case 2:
        return <Medal className="w-5 h-5 text-gray-400" />
      case 3:
        return <Medal className="w-5 h-5 text-amber-600" />
      default:
        return <span className="text-muted-foreground font-mono">#{rank}</span>
    }
  }

  return (
    <div className="px-4 py-6 space-y-6">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-bold text-foreground">Leaderboard</h1>
        <p className="text-muted-foreground mt-1">Weekly rankings</p>
      </motion.div>

      {/* Top 3 Podium */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-end justify-center gap-3 py-6"
      >
        {/* 2nd Place */}
        {sortedLeaderboard[1] && (
          <div className="flex flex-col items-center">
            <Avatar className="w-14 h-14 border-2 border-gray-400 mb-2">
              <AvatarImage src={sortedLeaderboard[1].avatar || "/placeholder.svg"} />
              <AvatarFallback>{sortedLeaderboard[1].name[0]}</AvatarFallback>
            </Avatar>
            <p className="text-sm font-medium text-foreground text-center truncate max-w-[80px]">
              {sortedLeaderboard[1].name.split(" ")[0]}
            </p>
            <div className="w-20 h-20 bg-gray-400/20 rounded-t-lg mt-2 flex items-center justify-center">
              <span className="text-2xl font-bold text-gray-400">2</span>
            </div>
          </div>
        )}

        {/* 1st Place */}
        {sortedLeaderboard[0] && (
          <div className="flex flex-col items-center">
            <motion.div animate={{ y: [0, -5, 0] }} transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}>
              <Trophy className="w-6 h-6 text-yellow-400 mb-1" />
            </motion.div>
            <Avatar className="w-16 h-16 border-2 border-yellow-400 mb-2">
              <AvatarImage src={sortedLeaderboard[0].avatar || "/placeholder.svg"} />
              <AvatarFallback>{sortedLeaderboard[0].name[0]}</AvatarFallback>
            </Avatar>
            <p className="text-sm font-medium text-foreground text-center truncate max-w-[80px]">
              {sortedLeaderboard[0].name.split(" ")[0]}
            </p>
            <div className="w-20 h-28 bg-yellow-400/20 rounded-t-lg mt-2 flex items-center justify-center">
              <span className="text-2xl font-bold text-yellow-400">1</span>
            </div>
          </div>
        )}

        {/* 3rd Place */}
        {sortedLeaderboard[2] && (
          <div className="flex flex-col items-center">
            <Avatar className="w-14 h-14 border-2 border-amber-600 mb-2">
              <AvatarImage src={sortedLeaderboard[2].avatar || "/placeholder.svg"} />
              <AvatarFallback>{sortedLeaderboard[2].name[0]}</AvatarFallback>
            </Avatar>
            <p className="text-sm font-medium text-foreground text-center truncate max-w-[80px]">
              {sortedLeaderboard[2].name.split(" ")[0]}
            </p>
            <div className="w-20 h-16 bg-amber-600/20 rounded-t-lg mt-2 flex items-center justify-center">
              <span className="text-2xl font-bold text-amber-600">3</span>
            </div>
          </div>
        )}
      </motion.div>

      {/* Full List */}
      <div className="space-y-2">
        {sortedLeaderboard.map((entry, index) => (
          <motion.div
            key={entry.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.05 }}
            className={`glass rounded-xl p-4 flex items-center gap-4 ${
              entry.isCurrentUser ? "border border-primary/30 neon-glow" : "border border-border/30"
            }`}
          >
            <div className="w-8 flex justify-center">{getRankIcon(index + 1)}</div>
            <Avatar className="w-10 h-10">
              <AvatarImage src={entry.avatar || "/placeholder.svg"} />
              <AvatarFallback>{entry.name[0]}</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="font-medium text-foreground truncate">
                {entry.name}
                {entry.isCurrentUser && <span className="text-primary text-xs ml-2">(You)</span>}
              </p>
              <p className="text-sm text-muted-foreground">
                Lv.{entry.level} • {entry.runs} runs
              </p>
            </div>
            <div className="text-right">
              <p className="font-semibold text-foreground">{entry.distance.toFixed(1)} km</p>
              {index < 3 && (
                <div className="flex items-center gap-1 text-xs text-primary">
                  <TrendingUp className="w-3 h-3" />
                  <span>Top {index + 1}</span>
                </div>
              )}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
